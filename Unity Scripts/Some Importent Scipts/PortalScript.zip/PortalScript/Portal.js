#pragma strict

var destination : Transform;
var normalParticle1 : ParticleSystem;
var normalParticle2 : ParticleSystem;
var teleportParticle : ParticleSystem;
var teleportSound : AudioClip;

function Start ()
{
	teleportParticle.Stop();
}

function OnTriggerEnter(other : Collider)
{
	if(other.tag == "Player")
	{
		normalParticle1.Stop();
		normalParticle2.Stop();
		teleportParticle.Play();
		yield WaitForSeconds (3);
		audio.PlayOneShot(teleportSound);
		yield WaitForSeconds (1);
		other.transform.position = destination.position;
	}
}

function OnTriggerExit(other : Collider)
{
		normalParticle1.Play();
		normalParticle2.Play();
		teleportParticle.Stop();
}