#pragma strict

var TorchClick : AudioClip;

var flashLight : Light;

function Start ()
{
	flashLight.light.enabled = false;
	flashLight.light.intensity = 8;
}

function Update () 
{
	if(flashLight.light.enabled == true)
	{
		flashLight.light.intensity -= 0.1 * Time.deltaTime / 5;
		Debug.Log(flashLight.light.intensity);
	}

	if(Input.GetKeyDown("f"))
	{
		audio.PlayOneShot(TorchClick);
		
	if(light.enabled == false)
	{
		flashLight.light.enabled = true;
	}
	else
	{
		flashLight.light.enabled = false;
	}
  }
}