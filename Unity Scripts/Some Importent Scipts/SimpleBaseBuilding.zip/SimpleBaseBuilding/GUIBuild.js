#pragma strict

var currentWood : int = 0;
var currentMetal : int = 0;
var currentBrick : int = 0;

function OnGUI()
{
	GUI.Box(Rect(5, 160, 40, 20), "Wood");
	GUI.Box(Rect(5, 180, 40, 20), "Metal");
	GUI.Box(Rect(5, 200, 40, 20), "Brick");
	
	GUI.Box(Rect(45, 160, 40, 20), "" + currentWood);
	GUI.Box(Rect(45, 180, 40, 20), "" + currentMetal);
	GUI.Box(Rect(45, 200, 40, 20), "" + currentBrick);
}