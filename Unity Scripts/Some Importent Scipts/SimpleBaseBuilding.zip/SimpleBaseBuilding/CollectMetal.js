#pragma strict

private var material : GUIBuild;

function Start()
{
	material = GameObject.Find("First Person Controller").GetComponent(GUIBuild);
}

function OnTriggerEnter(Col : Collider)
{
	if(Col.tag == "Player")
	{
		Destroy(gameObject);
		material.currentMetal++;
	}
}