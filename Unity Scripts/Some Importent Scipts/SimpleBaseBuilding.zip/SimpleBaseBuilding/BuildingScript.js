#pragma strict

private var material : GUIBuild;
private var canBuild : boolean = false;

var building1 : boolean = false;
var building2 : boolean = false;
var building3 : boolean = false;

function Start()
{
	material = GameObject.Find("First Person Controller").GetComponent(GUIBuild);
	building1 = true;
}

function OnTriggerEnter (Col : Collider)
{
	if(Col.tag == "Player")
	{
		canBuild = true;
		Debug.Log("WE ARE IN COLLIDER!");
	}
}

function OnTriggerExit (Col : Collider)
{
	if(Col.tag == "Player")
	{
		canBuild = false;
	}
}

function Update()
{
	if(canBuild == true && building1 == true)
	{
		if(Input.GetKeyDown("b"))
		{
			if(material.currentWood >= 1 && material.currentMetal >= 1 && material.currentBrick >= 1)
			{
				GameObject.Find("B1").GetComponent(MeshRenderer).enabled = false;
				GameObject.Find("B2").GetComponent(MeshRenderer).enabled = true;
				
				//Set materials to zero
				material.currentWood--;
				material.currentMetal--;
				material.currentBrick--;
				
				building1 = false;
				building2 = true;
			}
		}
	}
	
	if(canBuild == true && building2 == true)
	{
		if(Input.GetKeyDown("b"))
		{
			if(material.currentWood >= 1 && material.currentMetal >= 1 && material.currentBrick >= 1)
			{
				GameObject.Find("B2").GetComponent(MeshRenderer).enabled = false;
				GameObject.Find("B3").GetComponent(MeshRenderer).enabled = true;
				
				//Set materials to zero
				material.currentWood--;
				material.currentMetal--;
				material.currentBrick--;
				
				building2 = false;
				building3 = true;
			}
		}
	}
	
	if(canBuild == true && building3 == true)
	{
		if(Input.GetKeyDown("b"))
		{
			if(material.currentWood >= 1 && material.currentMetal >= 1 && material.currentBrick >= 1)
			{
				GameObject.Find("B3").GetComponent(MeshRenderer).enabled = false;
				GameObject.Find("B4").GetComponent(MeshRenderer).enabled = true;
				
				//Set materials to zero
				material.currentWood--;
				material.currentMetal--;
				material.currentBrick--;
				
				building3 = false;
			}
		}
	}
}