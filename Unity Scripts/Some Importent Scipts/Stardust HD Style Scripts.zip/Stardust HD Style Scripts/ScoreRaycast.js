﻿#pragma strict

var rayLength = 10;

var scoreItem : GameObject;

function Update()
{
	var hit : RaycastHit;
	var fwd = transform.TransformDirection(Vector3.forward);
	
	if(Physics.Raycast(transform.position, fwd, hit, rayLength))
	{
		if(hit.collider.gameObject.tag == "Score")
		{
			scoreItem = (hit.collider.gameObject);
			scoreItem.GetComponent(ScoreMoveTowards).IfVisible();
		}
	}
}