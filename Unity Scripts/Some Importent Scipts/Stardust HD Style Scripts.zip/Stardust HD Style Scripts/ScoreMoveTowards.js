﻿#pragma strict

var target: Transform;
var speed: float;	
var mainCamera : GameObject;

private var scoreScript : ScoreController;
private var moveTowards : boolean = false;
	
function Start()	
{
	scoreScript = mainCamera.GetComponent(ScoreController);
}

function IfVisible() 
{
	moveTowards = true;
}

function Update()
{
	if(moveTowards == true)
	{
		var step = speed * Time.deltaTime;
		
		transform.position = Vector3.MoveTowards(transform.position, target.position, step);
	}
}
function OnTriggerEnter(Col : Collider)
{
	if(Col.tag == "Player")
	{
		Debug.Log("TEST");
		scoreScript.score += 10;
		moveTowards = false;
		Destroy(gameObject);
	}
}