#pragma strict

var tex1 : Texture;
var tex2 : Texture;
var tex3 : Texture;
var tex4 : Texture;

var health : float = 100.0;

private var maxHealth : float = 100.0;
private var enterCollider : boolean = false;

//Damage Collider
function OnTriggerEnter (Col : Collider)
{
	if(Col.gameObject.tag == "Player")
	{
		enterCollider = true;
		Debug.Log("Is inside collider");
	}
}

function OnTriggerExit (Col : Collider)
{
	if(Col.gameObject.tag == "Player")
	{
		enterCollider = false;
	}
}

function Update ()
{
	//Health countdown whilst in the damage collider
	if(health > 0 && enterCollider == true)
	{
		health -= Time.deltaTime * 2;
	}
	
	//Normal health regeneration
	if(health >= 0 && enterCollider == false)
	{
		health += Time.deltaTime * 2;
	}
	
	//When health reaches 100, set to maxHealth
	if(health > maxHealth)
	{
		health = maxHealth;
	}
}

function OnGUI ()
{
	if (health <= 100)
	{
		GUI.DrawTexture(Rect(0,0, Screen.width, Screen.height), tex1);
	}
	
		if (health <= 95)
	{
		GUI.DrawTexture(Rect(0,0, Screen.width, Screen.height), tex2);
	}
	
		if (health <= 90)
	{
		GUI.DrawTexture(Rect(0,0, Screen.width, Screen.height), tex3);
	}
	
		if (health <= 85)
	{
		GUI.DrawTexture(Rect(0,0, Screen.width, Screen.height), tex4);
	}
}

