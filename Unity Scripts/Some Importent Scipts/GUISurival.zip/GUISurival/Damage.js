#pragma strict

private var survivalScript : GUISurvival;

function Start () 
{
	survivalScript = GameObject.Find("First Person Controller").GetComponent(GUISurvival);
}

function OnTriggerEnter (Col : Collider)
{
	if(Col.tag == "Player")
	{
		Destroy(gameObject);
		survivalScript.currentHealth -= 100;
	}
}