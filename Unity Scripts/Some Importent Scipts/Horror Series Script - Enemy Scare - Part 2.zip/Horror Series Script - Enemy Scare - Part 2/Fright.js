#pragma strict

private var sanityScript : InsanityManager;

var scarePerc : float = 20.0;

function Start()
{
	sanityScript = GameObject.Find("First Person Controller").GetComponent(InsanityManager);
}

function Update()
{
	var fwd = transform.TransformDirection(Vector3.forward);
	var hit : RaycastHit;
	
	if(Physics.Raycast(transform.position, fwd, hit))
	{
		if(hit.distance <= 10.0 && hit.collider.gameObject.tag == "Enemy")
		{			
			sanityScript.currentSanity += scarePerc * Time.deltaTime;
		}
	}
}