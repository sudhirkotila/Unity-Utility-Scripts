﻿#pragma strict

var mainCamera : Camera;
var hidingCamera : Camera;

private var guiShow : boolean = false;

 var isHiding : boolean = false;

var rayLength = 10;

function Start()
{
	mainCamera.camera.enabled = true;
	hidingCamera.camera.enabled = false;
}

function Update()
{
	var hit : RaycastHit;
	var fwd = transform.TransformDirection(Vector3.forward);
	
	if(Physics.Raycast(transform.position, fwd, hit, rayLength))
	{
		if(hit.collider.gameObject.tag == "Hide" && isHiding == false)
		{
			guiShow = true;
			if(Input.GetKeyDown("e"))
			{
				//Disable Player
				GameObject.Find("First Person Controller").GetComponent(FPSInputController).enabled = false;
				GameObject.Find("Graphics").GetComponent(MeshRenderer).enabled = false;
				
				//Cameras
				mainCamera.camera.enabled = false;
				hidingCamera.camera.enabled = true;
				
				//Booleans
				Wait();
			}
		}
	}
	
	else
	{
		guiShow = false;
	}
	
	if(isHiding == true)
	{
		if(Input.GetKeyDown("e"))
		{
			//Disable Player
			GameObject.Find("First Person Controller").GetComponent(FPSInputController).enabled = true;
			GameObject.Find("Graphics").GetComponent(MeshRenderer).enabled = true;
				
			//Cameras
			mainCamera.camera.enabled = true;
			hidingCamera.camera.enabled = false;
				
			//Booleans
			isHiding = false;
		}
	}
}

function Wait()
{
	yield WaitForSeconds(0.5);
	isHiding = true;
	guiShow = false;
}

function OnGUI()
{
	if(guiShow == true)
	{
		GUI.Box(Rect(Screen.width / 2, Screen.height / 2, 100, 25), "Hide inside?");
	}
}