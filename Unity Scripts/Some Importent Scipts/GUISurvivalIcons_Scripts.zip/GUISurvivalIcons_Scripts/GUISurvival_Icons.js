#pragma strict

var currentHealth : float = 100.0;
var maxHealth : int = 100;

var currentThirst : float = 100.0;
var maxThirst : int = 100;

var currentHunger : float = 100.0;
var maxHunger : int = 100;

private var barLength = 0.0;

//FALL RATES (Higher = Slower)
var thirstFallRate : int = 4;
var hungerFallRate	: int = 6;

//GUI Textures
var healthGood : Texture;
var healthNeutral : Texture;
var healthBad : Texture;
	
var thirstGood : Texture;
var thirstNeutral : Texture;
var thirstBad : Texture;
	
var hungerGood : Texture;
var hungerNeutral : Texture;
var hungerBad : Texture;

//GUI Booleans

private var guiHealthGood = false;
private var guiHealthNeutral = false;
private var guiHealthBad = false;

private var guiThirstGood = false;
private var guiThirstNeutral = false;
private var guiThirstBad = false;

private var guiHungerGood = false;
private var guiHungerNeutral = false;
private var guiHungerBad = false;

function Start()
{
	barLength = Screen.width / 8;
}

function Update()
{
	if(currentHealth <= 0)
	{
		CharacterDeath();
	}
	
	/* THIRST CONTROL SECTION*/
	
	//Normal thirst degredation
	if(currentThirst >= 0)
	{
		currentThirst -= Time.deltaTime / thirstFallRate;
	}
	
	if(currentThirst <= 0)
	{
		currentThirst = 0;
	}
	
	if(currentThirst >= maxThirst)
	{
		currentThirst = maxThirst;
	}
	
	/* HUNGER CONTROL SECTION*/
		if(currentHunger >= 0)
	{
		currentHunger -= Time.deltaTime / hungerFallRate;
	}
	
	if(currentHunger <= 0)
	{
		currentHunger = 0;
	}
	
	if(currentHunger >= maxHunger)
	{
		currentHunger = maxHunger;
	}
	
	/* DAMAGE CONTROL SECTION*/
	if(currentHunger <= 0 && (currentThirst <= 0))
	{
		currentHealth -= Time.deltaTime / 2;
	}
	
	else
	{
		if(currentHunger <= 0 || currentThirst <= 0)
		{
			currentHealth -= Time.deltaTime / 4;
		}
	}
	
	
	
	
	
	
	/*NEW SECTION*/
	
	if(currentHealth <= 100)
	{
		guiHealthGood = true;
		guiHealthNeutral = false;
		guiHealthBad = false;
	}
	
	if(currentHealth <= 50)
	{
		guiHealthGood = false;
		guiHealthNeutral = true;
		guiHealthBad = false;
	}
	
	if(currentHealth <= 25)
	{
		guiHealthGood = false;
		guiHealthNeutral = false;
		guiHealthBad = true;
	}
	
	/*NEW THIRST SECTION*/
	
	if(currentThirst <= 100)
	{
		guiThirstGood = true;
		guiThirstNeutral = false;
		guiThirstBad = false;
	}
	
	if(currentThirst <= 50)
	{
		guiThirstGood = false;
		guiThirstNeutral = true;
		guiThirstBad = false;
	}
	
	if(currentThirst <= 25)
	{
		guiThirstGood = false;
		guiThirstNeutral = false;
		guiThirstBad = true;
	}
	
	/*NEW HUNGER SECTION*/
	
	if(currentHunger <= 100)
	{
		guiHungerGood = true;
		guiHungerNeutral = false;
		guiHungerBad = false;
	}
	
	if(currentHunger <= 50)
	{
		guiHungerGood = false;
		guiHungerNeutral = true;
		guiHungerBad = false;
	}
	
	if(currentHunger <= 25)
	{
		guiHungerGood = false;
		guiHungerNeutral = false;
		guiHungerBad = true;
	}
}

function CharacterDeath()
{
	Application.LoadLevel("SimpleMenu");
}

function OnGUI()
{
	//Health Icons
	if(guiHealthGood == true)
	{
		GUI.DrawTexture(Rect(5, 30, 22.5, 33.75), healthGood);
	}
	
	if(guiHealthNeutral == true)
	{
		GUI.DrawTexture(Rect(5, 30, 22.5, 33.75), healthNeutral);
	}
	
	if(guiHealthBad == true)
	{
		GUI.DrawTexture(Rect(5, 30, 22.5, 33.75), healthBad);
	}
	
	//Thirst Icons
	if(guiThirstGood == true)
	{
		GUI.DrawTexture(Rect(5, 55, 22.5, 33.75), thirstGood);
	}
	
	if(guiThirstNeutral == true)
	{
		GUI.DrawTexture(Rect(5, 55, 22.5, 33.75), thirstNeutral);
	}
	
	if(guiThirstBad == true)
	{
		GUI.DrawTexture(Rect(5, 55, 22.5, 33.75), thirstBad);
	}
	
	//Hunger Icons
	if(guiHungerGood == true)
	{
		GUI.DrawTexture(Rect(5, 80, 22.5, 33.75), hungerGood);
	}
	
	if(guiHungerNeutral == true)
	{
		GUI.DrawTexture(Rect(5, 80, 22.5, 33.75), hungerNeutral);
	}
	
	if(guiHungerBad == true)
	{
		GUI.DrawTexture(Rect(5, 80, 22.5, 33.75), hungerBad);
	}
	
	//Health / Hunger / Thirst bars
	GUI.Box(new Rect(55, 30, barLength, 23), currentHealth.ToString("0") + "/" + maxHealth);
	GUI.Box(new Rect(55, 55, barLength, 23), currentThirst.ToString("0") + "/" + maxThirst);
	GUI.Box(new Rect(55, 80, barLength, 23), currentHunger.ToString("0") + "/" + maxHunger);
	
}