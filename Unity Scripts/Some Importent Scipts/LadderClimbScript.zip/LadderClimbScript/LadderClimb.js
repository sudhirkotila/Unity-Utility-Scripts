#pragma strict

var chController : Transform;
var inside : boolean = false;
var heightFactor : float = 3.2;

private var FPSInput : FPSInputController;

function Start()
{
	FPSInput = GetComponent(FPSInputController);
}

function OnTriggerEnter(Col : Collider)
{
	if(Col.gameObject.tag == "Ladder")
	{
		FPSInput.enabled = false;
		inside = !inside;
	}
}

function OnTriggerExit(Col : Collider)
{
	if(Col.gameObject.tag == "Ladder")
	{
		FPSInput.enabled = true;
		inside = !inside;
	}
}
		
function Update()
{
	if(inside == true && Input.GetKey("w"))
	{
			chController.transform.position += Vector3.up / heightFactor;
	}
}