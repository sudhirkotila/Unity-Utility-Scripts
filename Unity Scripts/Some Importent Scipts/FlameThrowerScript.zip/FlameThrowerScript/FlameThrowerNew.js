#pragma strict

var flameThrower : ParticleSystem;
var flames : AudioClip;

function Start ()
{
	flameThrower.emissionRate = 0.0f;
	GameObject.Find("FlameCollider").GetComponent(Collider).enabled = false;
}

function Update ()
{
	if(Input.GetMouseButton(0))
	{
		audio.PlayOneShot(flames);
		flameThrower.emissionRate = 150.0f;
		GameObject.Find("FlameCollider").GetComponent(Collider).enabled = true;
		
	}
	
	else
	{
		audio.Stop();
		flameThrower.emissionRate = 0.0f;
		GameObject.Find("FlameCollider").GetComponent(Collider).enabled = false;
	}
}