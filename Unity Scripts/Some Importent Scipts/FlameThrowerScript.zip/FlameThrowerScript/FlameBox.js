#pragma strict

var setOnFire : ParticleSystem;

function Start ()
{
	setOnFire.Stop();
}

function OnTriggerEnter (Col : Collider)
{
	if(Col.tag == "Fire")
	{
		setOnFire.Play();
	}
}