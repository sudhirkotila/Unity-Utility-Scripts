#pragma strict

var objective1 : boolean = false;
var objective2 : boolean = false;
var objective3 : boolean = false;
var objective4 : boolean = false;
var objective5 : boolean = false;

var texture1 : Texture;
var texture2 : Texture;
var texture3 : Texture;
var texture4 : Texture;
var texture5 : Texture;


function OnGUI()
{
	if(objective1 == true)
	{
		GUI.DrawTexture(Rect(10,10, 750,150), texture1);
	}
	
	if(objective2 == true)
	{
		GUI.DrawTexture(Rect(10,10, 750,150), texture2);
	}
	
	if(objective3 == true)
	{
		GUI.DrawTexture(Rect(10,10, 750,150), texture3);
	}
	
	if(objective4 == true)
	{
		GUI.DrawTexture(Rect(10,10, 750,150), texture4);
	}
	
	if(objective5 == true)
	{
		GUI.DrawTexture(Rect(10,10, 750,150), texture5);
	}
}
