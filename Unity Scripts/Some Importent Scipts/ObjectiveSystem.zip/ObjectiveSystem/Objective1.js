#pragma strict

private var objManager : ObjectiveManager;

function Start()
{
	objManager = GameObject.Find("First Person Controller").GetComponent(ObjectiveManager);
}

function OnTriggerEnter (Col : Collider)
{
	if(Col.tag == "Player")
	{
		Destroy(gameObject);
		objManager.objective1 = true;
		objManager.objective2 = false;
		objManager.objective3 = false;
		objManager.objective4 = false;
		objManager.objective5 = false;
	}
}