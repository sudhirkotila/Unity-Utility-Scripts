#pragma strict

var treeHealth : int = 100;

var apple : Transform;
var tree : Transform;

function TreeHit (treeHit : int)
{
	treeHealth -= treeHit;
	
	if(treeHealth <= 25)
	{
		var position : Vector3 = Vector3(Random.Range(-10.0, 10.0), 0, Random.Range(-10.0, 10.0));
		Instantiate(apple, tree.transform.position + Vector3(0,20,0) + position, Quaternion.identity);
		treeHealth = 100;
	}
}