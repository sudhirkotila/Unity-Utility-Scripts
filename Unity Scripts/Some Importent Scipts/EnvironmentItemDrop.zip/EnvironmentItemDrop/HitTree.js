#pragma strict

var treeHit : int = 25;
var distance : float;
var maxDistance : float = 1.5;

function Update()
{
	if(Input.GetButtonDown("Fire1"))
	{
		var hit : RaycastHit;
		if(Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), hit))
	{
		distance = hit.distance;
		if(distance < maxDistance)
		{
			hit.transform.SendMessage("TreeHit", treeHit, SendMessageOptions.DontRequireReceiver);
		}
	 }
   }
}